import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text("CustomPaint Demo"),
        ),
        body: Center(
          child: CustomPaint(
            size: Size(300, 300), // Size of the CustomPaint widget
            painter: MyCustomPainter(),
          ),
        ),
      ),
    );
  }
}

class MyCustomPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // Drawing a circle in the center
    final paint = Paint()
      ..color = Colors.blue
      ..strokeWidth = 5
      ..style = PaintingStyle.stroke;

    // Center point of the canvas
    final center = Offset(size.width / 2, size.height / 2);

    // Draw circle
    canvas.drawCircle(center, 100, paint);

    // Draw a line across the circle
    final linePaint = Paint()
      ..color = Colors.red
      ..strokeWidth = 4;

    canvas.drawLine(Offset(0, size.height / 2),
        Offset(size.width, size.height / 2), linePaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}
